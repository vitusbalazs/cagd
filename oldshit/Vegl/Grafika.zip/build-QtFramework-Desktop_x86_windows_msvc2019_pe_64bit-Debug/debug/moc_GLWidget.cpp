/****************************************************************************
** Meta object code from reading C++ file 'GLWidget.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../QtFramework_Lab45_vegleges/GUI/GLWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GLWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_cagd__GLWidget_t {
    const uint offsetsAndSize[110];
    char stringdata0[837];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_cagd__GLWidget_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_cagd__GLWidget_t qt_meta_stringdata_cagd__GLWidget = {
    {
QT_MOC_LITERAL(0, 14), // "cagd::GLWidget"
QT_MOC_LITERAL(15, 12), // "setSelectedX"
QT_MOC_LITERAL(28, 0), // ""
QT_MOC_LITERAL(29, 5), // "value"
QT_MOC_LITERAL(35, 12), // "setSelectedY"
QT_MOC_LITERAL(48, 12), // "setSelectedZ"
QT_MOC_LITERAL(61, 14), // "distanceSignal"
QT_MOC_LITERAL(76, 11), // "set_angle_x"
QT_MOC_LITERAL(88, 11), // "set_angle_y"
QT_MOC_LITERAL(100, 11), // "set_angle_z"
QT_MOC_LITERAL(112, 15), // "set_zoom_factor"
QT_MOC_LITERAL(128, 11), // "set_trans_x"
QT_MOC_LITERAL(140, 11), // "set_trans_y"
QT_MOC_LITERAL(152, 11), // "set_trans_z"
QT_MOC_LITERAL(164, 9), // "set_scale"
QT_MOC_LITERAL(174, 5), // "scale"
QT_MOC_LITERAL(180, 19), // "set_div_point_count"
QT_MOC_LITERAL(200, 15), // "div_point_count"
QT_MOC_LITERAL(216, 23), // "setParametricCurveIndex"
QT_MOC_LITERAL(240, 5), // "index"
QT_MOC_LITERAL(246, 23), // "setVisibilityOfTangents"
QT_MOC_LITERAL(270, 10), // "visibility"
QT_MOC_LITERAL(281, 34), // "setVisibilityOfAccelerationVe..."
QT_MOC_LITERAL(316, 7), // "animate"
QT_MOC_LITERAL(324, 22), // "setSelectedCyclicCurve"
QT_MOC_LITERAL(347, 16), // "setSelectedPoint"
QT_MOC_LITERAL(364, 26), // "setVisibilityOfCyclicCurve"
QT_MOC_LITERAL(391, 22), // "setVisibilityOfTangent"
QT_MOC_LITERAL(414, 32), // "setVisiblityOfAccelerationVector"
QT_MOC_LITERAL(447, 11), // "visiblility"
QT_MOC_LITERAL(459, 23), // "setSpeedOfSelectedCurve"
QT_MOC_LITERAL(483, 16), // "setSelectedXSlot"
QT_MOC_LITERAL(500, 16), // "setSelectedYSlot"
QT_MOC_LITERAL(517, 16), // "setSelectedZSlot"
QT_MOC_LITERAL(534, 12), // "distanceSlot"
QT_MOC_LITERAL(547, 18), // "setSelectedSurface"
QT_MOC_LITERAL(566, 19), // "setSelectedMaterial"
QT_MOC_LITERAL(586, 18), // "setSelectedTexture"
QT_MOC_LITERAL(605, 22), // "setVisibilityOfTexture"
QT_MOC_LITERAL(628, 14), // "animateSurface"
QT_MOC_LITERAL(643, 17), // "setSelectedShader"
QT_MOC_LITERAL(661, 14), // "setShaderScale"
QT_MOC_LITERAL(676, 12), // "setSmoothing"
QT_MOC_LITERAL(689, 10), // "setShading"
QT_MOC_LITERAL(700, 6), // "setRed"
QT_MOC_LITERAL(707, 7), // "setBlue"
QT_MOC_LITERAL(715, 8), // "setGreen"
QT_MOC_LITERAL(724, 11), // "set_u_lines"
QT_MOC_LITERAL(736, 11), // "set_v_lines"
QT_MOC_LITERAL(748, 11), // "set_u_deriv"
QT_MOC_LITERAL(760, 11), // "set_v_deriv"
QT_MOC_LITERAL(772, 13), // "set_after_int"
QT_MOC_LITERAL(786, 14), // "set_arc_deriv1"
QT_MOC_LITERAL(801, 14), // "set_arc_deriv2"
QT_MOC_LITERAL(816, 20) // "set_show_control_net"

    },
    "cagd::GLWidget\0setSelectedX\0\0value\0"
    "setSelectedY\0setSelectedZ\0distanceSignal\0"
    "set_angle_x\0set_angle_y\0set_angle_z\0"
    "set_zoom_factor\0set_trans_x\0set_trans_y\0"
    "set_trans_z\0set_scale\0scale\0"
    "set_div_point_count\0div_point_count\0"
    "setParametricCurveIndex\0index\0"
    "setVisibilityOfTangents\0visibility\0"
    "setVisibilityOfAccelerationVectors\0"
    "animate\0setSelectedCyclicCurve\0"
    "setSelectedPoint\0setVisibilityOfCyclicCurve\0"
    "setVisibilityOfTangent\0"
    "setVisiblityOfAccelerationVector\0"
    "visiblility\0setSpeedOfSelectedCurve\0"
    "setSelectedXSlot\0setSelectedYSlot\0"
    "setSelectedZSlot\0distanceSlot\0"
    "setSelectedSurface\0setSelectedMaterial\0"
    "setSelectedTexture\0setVisibilityOfTexture\0"
    "animateSurface\0setSelectedShader\0"
    "setShaderScale\0setSmoothing\0setShading\0"
    "setRed\0setBlue\0setGreen\0set_u_lines\0"
    "set_v_lines\0set_u_deriv\0set_v_deriv\0"
    "set_after_int\0set_arc_deriv1\0"
    "set_arc_deriv2\0set_show_control_net"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_cagd__GLWidget[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      47,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  296,    2, 0x06,    1 /* Public */,
       4,    1,  299,    2, 0x06,    3 /* Public */,
       5,    1,  302,    2, 0x06,    5 /* Public */,
       6,    1,  305,    2, 0x06,    7 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       7,    1,  308,    2, 0x0a,    9 /* Public */,
       8,    1,  311,    2, 0x0a,   11 /* Public */,
       9,    1,  314,    2, 0x0a,   13 /* Public */,
      10,    1,  317,    2, 0x0a,   15 /* Public */,
      11,    1,  320,    2, 0x0a,   17 /* Public */,
      12,    1,  323,    2, 0x0a,   19 /* Public */,
      13,    1,  326,    2, 0x0a,   21 /* Public */,
      14,    1,  329,    2, 0x0a,   23 /* Public */,
      16,    1,  332,    2, 0x0a,   25 /* Public */,
      18,    1,  335,    2, 0x0a,   27 /* Public */,
      20,    1,  338,    2, 0x0a,   29 /* Public */,
      22,    1,  341,    2, 0x0a,   31 /* Public */,
      23,    0,  344,    2, 0x0a,   33 /* Public */,
      24,    1,  345,    2, 0x0a,   34 /* Public */,
      25,    1,  348,    2, 0x0a,   36 /* Public */,
      26,    1,  351,    2, 0x0a,   38 /* Public */,
      27,    1,  354,    2, 0x0a,   40 /* Public */,
      28,    1,  357,    2, 0x0a,   42 /* Public */,
      30,    1,  360,    2, 0x0a,   44 /* Public */,
      31,    1,  363,    2, 0x0a,   46 /* Public */,
      32,    1,  366,    2, 0x0a,   48 /* Public */,
      33,    1,  369,    2, 0x0a,   50 /* Public */,
      34,    1,  372,    2, 0x0a,   52 /* Public */,
      35,    1,  375,    2, 0x0a,   54 /* Public */,
      36,    1,  378,    2, 0x0a,   56 /* Public */,
      37,    1,  381,    2, 0x0a,   58 /* Public */,
      38,    1,  384,    2, 0x0a,   60 /* Public */,
      39,    0,  387,    2, 0x0a,   62 /* Public */,
      40,    1,  388,    2, 0x0a,   63 /* Public */,
      41,    1,  391,    2, 0x0a,   65 /* Public */,
      42,    1,  394,    2, 0x0a,   67 /* Public */,
      43,    1,  397,    2, 0x0a,   69 /* Public */,
      44,    1,  400,    2, 0x0a,   71 /* Public */,
      45,    1,  403,    2, 0x0a,   73 /* Public */,
      46,    1,  406,    2, 0x0a,   75 /* Public */,
      47,    1,  409,    2, 0x0a,   77 /* Public */,
      48,    1,  412,    2, 0x0a,   79 /* Public */,
      49,    1,  415,    2, 0x0a,   81 /* Public */,
      50,    1,  418,    2, 0x0a,   83 /* Public */,
      51,    1,  421,    2, 0x0a,   85 /* Public */,
      52,    1,  424,    2, 0x0a,   87 /* Public */,
      53,    1,  427,    2, 0x0a,   89 /* Public */,
      54,    1,  430,    2, 0x0a,   91 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,   15,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void, QMetaType::Bool,   29,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Double,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,

       0        // eod
};

void cagd::GLWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GLWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->setSelectedX((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 1: _t->setSelectedY((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 2: _t->setSelectedZ((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 3: _t->distanceSignal((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 4: _t->set_angle_x((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->set_angle_y((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->set_angle_z((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->set_zoom_factor((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 8: _t->set_trans_x((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 9: _t->set_trans_y((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 10: _t->set_trans_z((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 11: _t->set_scale((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 12: _t->set_div_point_count((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->setParametricCurveIndex((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->setVisibilityOfTangents((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: _t->setVisibilityOfAccelerationVectors((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 16: _t->animate(); break;
        case 17: _t->setSelectedCyclicCurve((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->setSelectedPoint((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->setVisibilityOfCyclicCurve((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->setVisibilityOfTangent((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 21: _t->setVisiblityOfAccelerationVector((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->setSpeedOfSelectedCurve((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->setSelectedXSlot((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 24: _t->setSelectedYSlot((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 25: _t->setSelectedZSlot((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 26: _t->distanceSlot((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 27: _t->setSelectedSurface((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 28: _t->setSelectedMaterial((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->setSelectedTexture((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->setVisibilityOfTexture((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 31: _t->animateSurface(); break;
        case 32: _t->setSelectedShader((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 33: _t->setShaderScale((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 34: _t->setSmoothing((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 35: _t->setShading((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 36: _t->setRed((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 37: _t->setBlue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 38: _t->setGreen((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 39: _t->set_u_lines((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 40: _t->set_v_lines((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 41: _t->set_u_deriv((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 42: _t->set_v_deriv((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 43: _t->set_after_int((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 44: _t->set_arc_deriv1((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 45: _t->set_arc_deriv2((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 46: _t->set_show_control_net((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GLWidget::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GLWidget::setSelectedX)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (GLWidget::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GLWidget::setSelectedY)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (GLWidget::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GLWidget::setSelectedZ)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (GLWidget::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GLWidget::distanceSignal)) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject cagd::GLWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QOpenGLWidget::staticMetaObject>(),
    qt_meta_stringdata_cagd__GLWidget.offsetsAndSize,
    qt_meta_data_cagd__GLWidget,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_cagd__GLWidget_t
, QtPrivate::TypeAndForceComplete<GLWidget, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>


>,
    nullptr
} };


const QMetaObject *cagd::GLWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *cagd::GLWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_cagd__GLWidget.stringdata0))
        return static_cast<void*>(this);
    return QOpenGLWidget::qt_metacast(_clname);
}

int cagd::GLWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QOpenGLWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 47)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 47;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 47)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 47;
    }
    return _id;
}

// SIGNAL 0
void cagd::GLWidget::setSelectedX(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void cagd::GLWidget::setSelectedY(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void cagd::GLWidget::setSelectedZ(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void cagd::GLWidget::distanceSignal(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
